package com.example.new_community_forum_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
