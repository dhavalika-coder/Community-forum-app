import 'package:flutter/material.dart';

void main() {
  runApp(const DoubtForumApp());
}

class DoubtForumApp extends StatelessWidget {
  const DoubtForumApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Doubt Discussion Forum',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const ForumHomePage(),
      debugShowCheckedModeBanner: false,
      routes: {
        ThreadDetailScreen.routeName: (context) => const ThreadDetailScreen(),
      },
    );
  }
}

/// ---------------------------------------------------------------
///  Home page
/// ---------------------------------------------------------------
class ForumHomePage extends StatefulWidget {
  static const routeName = '/';

  const ForumHomePage({Key? key}) : super(key: key);

  @override
  State<ForumHomePage> createState() => _ForumHomePageState();
}

enum SortMode { newest, topVotes }

class _ForumHomePageState extends State<ForumHomePage> {
  SortMode sortMode = SortMode.newest;
  String query = '';

  // Dummy threads – replace with real data / Firebase later
  final List<Thread> _threads = List.generate(
    12,
    (i) => Thread(
      id: i,
      title: 'How to $i handle null safety in Dart?',
      body: 'I keep getting “null check operator used on a null value”...',
      author: 'User${i + 1}',
      votes: i * 3,
      tags: ['dart', 'flutter', i.isEven ? 'null-safety' : 'error'],
      timestamp: DateTime.now().subtract(Duration(hours: i)),
    ),
  );

  // -----------------------------------------------------------------
  // Helper: chip for a single tag
  // -----------------------------------------------------------------
  Widget _tagChip(String tag) => Container(
        margin: const EdgeInsets.only(right: 6),
        child: Chip(
          label: Text(tag),
          visualDensity: VisualDensity.compact,
        ),
      );

  // -----------------------------------------------------------------
  // Placeholder for creating a new thread
  // -----------------------------------------------------------------
  void _createThread() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Create thread – implement dialog here')),
    );
  }

  // -----------------------------------------------------------------
  // Build the UI
  // -----------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    // Filter & sort threads
    final filtered = _threads.where((t) {
      final q = query.toLowerCase();
      return t.title.toLowerCase().contains(q) ||
          t.body.toLowerCase().contains(q) ||
          t.tags.any((tag) => tag.toLowerCase().contains(q));
    }).toList();

    if (sortMode == SortMode.topVotes) {
      filtered.sort((a, b) => b.votes.compareTo(a.votes));
    } else {
      filtered.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Doubt Discussion Forum'),
        actions: [
          IconButton(
            icon: Icon(
              sortMode == SortMode.newest ? Icons.fiber_new : Icons.star,
            ),
            tooltip: 'Toggle sort',
            onPressed: () {
              setState(() {
                sortMode = sortMode == SortMode.newest
                    ? SortMode.topVotes
                    : SortMode.newest;
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _createThread,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search title, body, or tags...',
                fillColor: Colors.white,
                filled: true,
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onChanged: (v) => setState(() => query = v),
            ),
          ),
        ),
      ),
      body: filtered.isEmpty
          ? const Center(child: Text('No threads match your search'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: filtered.length,
              itemBuilder: (context, i) {
                final thread = filtered[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    title: Text(
                      thread.title,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          thread.body,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Wrap(children: thread.tags.map(_tagChip).toList()),
                      ],
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.arrow_upward,
                            size: 16, color: Colors.green[700]),
                        Text('${thread.votes}'),
                      ],
                    ),
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        ThreadDetailScreen.routeName,
                        arguments: thread,
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}

/// ---------------------------------------------------------------
///  Thread Detail Screen (Stub)
// ---------------------------------------------------------------
class ThreadDetailScreen extends StatelessWidget {
  static const routeName = '/thread-detail';

  const ThreadDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Thread thread = ModalRoute.of(context)!.settings.arguments as Thread;

    return Scaffold(
      appBar: AppBar(title: Text(thread.title)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('By ${thread.author}', style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 8),
            Text(thread.body, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            Wrap(children: thread.tags.map((t) => Chip(label: Text(t))).toList()),
            const Divider(height: 32),
            const Text('Comments will appear here...', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------
///  Simple data model for a forum thread
/// ---------------------------------------------------------------
class Thread {
  final int id;
  final String title;
  final String body;
  final String author;
  final int votes;
  final List<String> tags;
  final DateTime timestamp;

  const Thread({
    required this.id,
    required this.title,
    required this.body,
    required this.author,
    required this.votes,
    required this.tags,
    required this.timestamp,
  });
}